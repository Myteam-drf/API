<?php
            require(APPPATH.'/libraries/REST_Controller.php');

            class Api extends REST_Controller{

            public function __construct()
            {
            parent::__construct();

            $this->load->model('mytask_model');
            }

            //API - get data 
            function mydemotask_get(){

            $rdtask  = $this->get('rajivtask');

            if(!$rdtask){

            $this->response("No rajivtask specified", 400);

            exit;
            }

            $result = $this->mytask_model->getmydata( $rdtask );

            if($result){

            $this->response($result, 200); 

            exit;
            } 
            else{

            $this->response("Invalid rajivtask", 404);

            exit;
            }
            } 

            //API -  Fetch All information 
            function rajivtask_get(){

            $result = $this->mytask_model->getallrajivdata();

            if($result){

            $this->response($result, 200); 

            } 

            else{

            $this->response("No record found", 404);

            }
            }

            //API - create a new information in database.
            function addrdata_post(){



            $name      = $this->post('name');

            $email  = $this->post('email');

            $language  = $this->post('language');

            $phone      = $this->post('phone');

            $pub_date  = $this->post('publish_date');

            if(!$name || !$email || !$language || !$phone || !$pub_date){

            $this->response("Enter my all data", 400);

            }else{

            $result = $this->mytask_model->add(array("name"=>$name, "email"=>$email, "language"=>$language, "phone"=>$phone, "pub_date"=>$pub_date));

            if($result === 0){

            $this->response("Rajiv information  not be saved. check once.", 404);

            }else{

            $this->response("success", 200);  

            }

            }

            }


            //API - update data 
            function uprdata_put(){

            $name      = $this->post('name');

            $email  = $this->post('email');

            $language  = $this->post('language');

            $phone      = $this->post('phone');

            $pub_date  = $this->post('publish_date');

            if(!$name || !$email || !$language || !$phone || !$pub_date){

            $this->response("information to save", 400);

            }else{
            $result = $this->mytask_model->update($id, array("name"=>$name, "email"=>$email, "language"=>$language, "phone"=>$phone, "pub_date"=>$pub_date));


            if($result === 0){

            $this->response("Rajiv information  not be saved. check once.", 404);

            }else{

            $this->response("success", 200);  

            }

            }

            }

            //API - delete data  
            function deleterdata_delete()
            {

            $id  = $this->delete('id');

            if(!$id){

            $this->response("Parameter missing", 404);

            }

            if($this->mytask_model->delete($id))
            {

            $this->response("Success", 200);

            } 
            else
            {

            $this->response("Failed", 400);

            }

            }


            }