<?php
  class Mytask_model extends CI_Model {
       
      public function __construct(){
          
        $this->load->database();
        
      }
      
      //API call - get  record table
      public function getmydata($rdtask){  

           $this->db->select('id, name, email, language, phone, publish_date');

           $this->db->from('tbl_rajiv');

           $this->db->where('rajivtask',$rdtask);

           $query = $this->db->get();
           
           if($query->num_rows() == 1)
           {

               return $query->result_array();

           }
           else
           {

             return 0;

          }

      }

    //API call - get all RAJIV record
    public function getallrajivdata(){   

        $this->db->select('id, name, email, language, phone, publish_date');

        $this->db->from('tbl_rajiv');

        $this->db->order_by("id", "desc"); 

        $query = $this->db->get();

        if($query->num_rows() > 0){

          return $query->result_array();

        }else{

          return 0;

        }

    }
   
   //API call - delete  record
    public function delete($id){

       $this->db->where('id', $id);

       if($this->db->delete('tbl_rajiv')){

          return true;

        }else{

          return false;

        }

   }
   
   //API call - add new  record
    public function add($data){

        if($this->db->insert('tbl_rajiv', $data)){

           return true;

        }else{

           return false;

        }

    }
    
    //API call - update record
    public function update($id, $data){

       $this->db->where('id', $id);

       if($this->db->update('tbl_rajiv', $data)){

          return true;

        }else{

          return false;

        }

    }

}