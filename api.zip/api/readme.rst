###################
Programmer Blog - RESTful Webservices in CodeIgniter
###################

Download code or clone repository in to your system. If you have GIT installed. Open command line and go to root direcotry (www or wwwroot) of your WAMP, MAMP or XAMPP directory.

Type following command.

 ```  git clone git@github.com:programmer-blog/restful-services-in-codeigniter.git ```

*******************
Create a MYSQL database
*******************

Create a MySQL database `dbbookstore` using phpMyAdmin


**************************
Create a books table
**************************
There is a **db** directory in the repository. This direcotry contains SQL commands for creating and populating data into SQL books table. 
Copy SQL commands and run in SQL tab of PHPMyAdmin.


*******************
Install Postman extension of Google Chrome
*******************

In Postman, you can test all the HTTP methods.

************
To read a detailed tutorial.
************
`http://programmerblog.net/create-restful-web-services-in-codeigniter`

*******
Programmer Blog
*******

`http://programmerblog.net/`

